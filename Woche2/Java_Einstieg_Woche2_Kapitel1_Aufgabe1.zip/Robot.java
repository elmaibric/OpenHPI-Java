class Robot {
    void speakTwice(String satz){
        System.out.println(satz);
        System.out.println(satz);
    }
}
