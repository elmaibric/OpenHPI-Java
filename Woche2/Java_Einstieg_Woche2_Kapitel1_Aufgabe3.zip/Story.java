class Story {
	public static void main(String[] args) {
		GPS koordinaten = new GPS();
		
		System.out.println(koordinaten.getCoordinates("hoehe"));
	}
}
