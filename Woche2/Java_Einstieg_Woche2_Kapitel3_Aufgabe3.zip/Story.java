class Story {

	public static void main(String[] args) {
		int number = 2;
		Robot robin = new Robot();
		robin.testNumber(number);
	}

}
