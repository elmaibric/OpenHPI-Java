class RandomNumberGreaterTen {

    RandomNumber rand = new RandomNumber();

    int greaterTen(){
         while (rand.giveNumber() < 10 ){
         rand.giveNumber();
    }
    return rand.giveNumber();
}
}
