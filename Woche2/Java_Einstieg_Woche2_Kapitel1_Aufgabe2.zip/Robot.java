class Robot {
    String completeName(String vorname, String nachname){
        return vorname + " " + nachname;
    }
}
