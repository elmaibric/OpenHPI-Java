class Robot {
    int batteryRuntime = 5;

    Robot() {
        this.batteryRuntime = batteryRuntime;
    }

}
