public class ReplacementPart {
    String color;
    String type;
    int size;
    
    // schreibe den Konstruktor hier hin
    ReplacementPart(String type, String color, int size){
        this.type = type;
        this.color = color;
        this.size = size;
    }
}