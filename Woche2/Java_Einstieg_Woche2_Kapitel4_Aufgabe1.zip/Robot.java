class Robot {

    void countTo(int number){
        for(int i = 1; i <= number; i++){
            System.out.println(i);
        }
    }


}