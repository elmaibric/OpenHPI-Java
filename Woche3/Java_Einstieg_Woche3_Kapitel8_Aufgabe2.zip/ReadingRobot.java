class ReadingRobot extends Robot {

    ReadingRobot(){
        super(5);
    }

}
