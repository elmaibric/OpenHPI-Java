class DecodeRobot {

    void tap(String text, int num){
        for(int i = 0; i < num; i++){
            System.out.println(text);
        }
    }
    
    void tap(String text){
        tap(text,3);
    }

}
