public class MathRobot {
    int addition(int zahl1, int zahl2){
        return zahl1+zahl2;
    }
    int addition(int zahl1, int zahl2, int zahl3){
        return zahl1+zahl2+zahl3;
    }
    double addition(double zahl1, double zahl2){
        return zahl1+zahl2;
    }
    double addition(double zahl1, double zahl2, double zahl3){
        return zahl1+zahl2+zahl3;
    }

}
