class Robot {
	private int batteryRuntime = 0;

	public void setBatteryRuntime(int newTime) {
	    if (notNegative(newTime)) {
		    batteryRuntime = newTime;
		    }
	}
	
	private boolean notNegative(int time){
	    if(time >= 0){
	        return true;
	    }else{
	        return false;
	    }
	}

	public int getBatteryRuntime() {
		return batteryRuntime;
	}
}
