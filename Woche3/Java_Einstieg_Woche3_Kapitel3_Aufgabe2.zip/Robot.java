class Robot {
	private boolean activated = false;

	public void printStatus() {
		System.out.println(activated);
	}
	
	public void setActivated(boolean set){
	    this.activated = set;
	}
	
	public boolean isActivated(){
	    return activated;
	}
}
