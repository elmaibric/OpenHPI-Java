class OldRobot {
	void greetUser() {
		System.out.println("Hallo User!");
	}

	int getInternalStorageSize() {
		return 5;
	}
}
