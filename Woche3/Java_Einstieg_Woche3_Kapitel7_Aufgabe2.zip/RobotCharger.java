class RobotCharger extends Robot{

    void chargeRobot(Robot robot){
        robot.batteryRuntime = robot.batteryRuntime + 7;
    }

}
