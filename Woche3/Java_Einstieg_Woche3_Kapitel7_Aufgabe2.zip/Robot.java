abstract class Robot {

	int batteryRuntime;

}
