abstract class Robot {
    void saySomething(){
    }
}