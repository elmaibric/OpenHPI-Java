class Story {

	public static void main(String args[]) {
		Robot ronja = new Robot();
		System.out.println("Die id von Ronja ist " + ronja.id); 
	}

}
