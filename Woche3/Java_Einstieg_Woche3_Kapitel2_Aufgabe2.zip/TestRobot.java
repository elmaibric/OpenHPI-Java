class TestRobot {
	private int secretKey = 602413;
	protected int numberOfProcessorCores = 4;
	boolean hasFirewall = false;
	public String id = "58-08-2";
}
