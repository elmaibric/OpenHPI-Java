class Terminal extends TestRobot{

    public void hackRobot(TestRobot tr){
        System.out.println(numberOfProcessorCores + " " + hasFirewall + " " + id);
    }
}
