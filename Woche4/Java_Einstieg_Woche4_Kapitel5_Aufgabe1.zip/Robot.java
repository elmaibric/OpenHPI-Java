public class Robot implements Flyable {

    public void fly(){
        System.out.println("ICh fliege mit meinen Raketen!");
    }

}
