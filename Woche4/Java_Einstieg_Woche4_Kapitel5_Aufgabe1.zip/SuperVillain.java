public class SuperVillain implements Flyable{

    public void fly(){
        System.out.println("Ich fliege mit meinem SuperVillain-Umhang!");
    }

}
