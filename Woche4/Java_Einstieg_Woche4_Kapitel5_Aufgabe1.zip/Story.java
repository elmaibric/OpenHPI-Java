public class Story {

	public static void main(String[] args) {
		Parrot paco = new Parrot();		
		Robot ronja = new Robot();		
		SuperVillain eikeVil = new SuperVillain();
		paco.fly();
		ronja.fly();
		eikeVil.fly();
	}

}
