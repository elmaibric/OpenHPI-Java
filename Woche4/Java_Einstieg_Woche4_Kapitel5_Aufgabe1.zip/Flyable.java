interface Flyable {
    void fly();
}