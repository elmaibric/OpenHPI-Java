import java.util.ArrayList;

public class Robot {

    void giveAccessCodes(ArrayList<String> liste){
        for(String s : liste){
            System.out.println(s);
        }
    }
}
