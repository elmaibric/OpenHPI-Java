interface Catchable {
    void tryToCatch(boolean b);
}
