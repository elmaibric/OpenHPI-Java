public class MathRobot {
	public double div(String a, String b) {
	    double x = Double.parseDouble(a);
	    double y = Double.parseDouble(b);
	    double z = x / y;
	    return z;
		// Füge hier deinen Code ein
	}
}
