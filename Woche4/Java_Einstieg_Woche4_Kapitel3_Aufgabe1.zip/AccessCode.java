class AccessCode {

	private String code = "";

	public void setCode(String code) {
		this.code = code;
	}
	
	public String getCode() {
		return this.code;
	}

}
