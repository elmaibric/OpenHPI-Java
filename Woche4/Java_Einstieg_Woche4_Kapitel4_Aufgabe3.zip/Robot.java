public class Robot {
	private String name;
	private String[] accessCodes = new String[]{"Mein ", "Zugangscode ", "ist ", "mein ", "Name: "};

	public Robot(String name) {
	this.name = name;
	}


	public String getAccessCode() {
		// Füge hier dein Code ein
		String out = new String();
		
		for (String str : accessCodes) {
		    out += str;
		}
		
		return out += name;
	}
}
