public class Robot {

	private String name;
	private String id;
	private int age;

	Robot(String name, String id, int age) {
		this.name = name;
		this.id = id;
		this.age = age;
	}
	
	@Override
	public String toString(){
	    String underline = "_";
	    String output = this.name + underline;
	    output += this.id + underline;
	    output += this.age;
	    return output;
	}
}
