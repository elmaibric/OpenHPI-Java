public class Story {

	public static void main(String[] args) {
		Robot ronja = new Robot("Ronja", "ak2jsd3125", 2);
		Robot robin = new Robot("Robin", "asd453ln", 5);
		System.out.println(ronja.toString());
		System.out.println(robin.toString()); 
	}
}
