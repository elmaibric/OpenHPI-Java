public class MathRobot {
	public double div(int a, int b) {
		// Füge hier deinen Code ein
		return a / (double) b;
	}
}
