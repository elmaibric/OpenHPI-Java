public class Story {
	public static void main(String args[]) {
		MathRobot ronja = new MathRobot();
		System.out.println("5 durch 3 ist: " + ronja.div(5,3));
		System.out.println("4 durch 2 ist: " + ronja.div(4,2));
	}
}
